package com.example.orderf_ood.presenter.tutorial;

public class TutorialPresenter {
    // なし
}