package com.example.orderf_ood.presenter.tutorial;

public interface ITutorialPresenter {
    // なし
}