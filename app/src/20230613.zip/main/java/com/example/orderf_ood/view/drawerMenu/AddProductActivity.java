package com.example.orderf_ood.view.drawerMenu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.orderf_ood.R;

/**
 * Add Product Fragment
 */
public class AddProductActivity extends AppCompatActivity implements View.OnClickListener {
    private Button mAddProductButton;
    private Button mAddTestButton1;
    private Button mAddTestButton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        initView();
    }

    private void initView() {
        mAddProductButton = findViewById(R.id.add_product_button);
        mAddProductButton.setOnClickListener(this);
        mAddTestButton1 = findViewById(R.id.test_button_1);
        mAddProductButton.setOnClickListener(this);
        mAddTestButton2 = findViewById(R.id.test_button_2);
        mAddProductButton.setOnClickListener(this);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.add_product_button:
                    AddProductFragment fragment = new AddProductFragment();

                break;
            case R.id.test_button_1:
                //TODO:
                break;
            case R.id.test_button_2:
                break;


        }
    }
}
