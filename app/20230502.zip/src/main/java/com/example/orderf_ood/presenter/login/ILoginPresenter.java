package com.example.orderf_ood.presenter.login;

public interface ILoginPresenter {
    // なし
}