package com.example.orderf_ood.model.tutorial;

public interface ITutorialInteract {
    // なし
}