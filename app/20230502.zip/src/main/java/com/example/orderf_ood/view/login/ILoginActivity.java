package com.example.orderf_ood.view.login;

public interface ILoginActivity {
   // なし
}