package com.example.orderf_ood.view.tutorial;

public interface ITutorialActivity {
    void openLoginView();
}