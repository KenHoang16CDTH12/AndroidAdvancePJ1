package com.example.orderf_ood.view.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.orderf_ood.R;
import com.example.orderf_ood.core.data.local.model.FoodModel;
import com.flaviofaria.kenburnsview.KenBurnsView;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CustomFoodGridAdapter extends BaseAdapter {
    private List<FoodModel> mListFood;
    private LayoutInflater mLayoutInflater;
    private Context context;

    public CustomFoodGridAdapter(List<FoodModel> listFood, Context context) {
        this.mListFood = listFood;
        this.mLayoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.context = context;
    }

    @Override
    public int getCount() {
        return mListFood.size();
    }

    @Override
    public FoodModel getItem(int position) {
        return mListFood.get(position);
    }

    @Override
    public long getItemId(int position) {
        return mListFood.get(position).getId();
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        view = mLayoutInflater.inflate(R.layout.item_grid_food,null);
        ImageView imageFood = view.findViewById(R.id.image_food);
        TextView tvNameFood = view.findViewById(R.id.tv_food_name);
        TextView tvPriceFood = view.findViewById(R.id.tv_food_price);
        Button btnAddToCard = view.findViewById(R.id.btn_add_to_card);
        ProgressBar progressBar = view.findViewById(R.id.progres_bar);

        //prepare food data
        final FoodModel data = getItem(position);

        //image -> hien thi hinh anh  bang url
        Picasso.get().
                load(data.getUrl())
                .placeholder(R.drawable.failed_image)
                .error(R.drawable.failed_image)
                .into(imageFood, new Callback() {
                    @Override
                    public void onSuccess() {
                        progressBar.setVisibility(View.GONE);
                    }

                    @Override
                    public void onError(Exception e) {
                        progressBar.setVisibility(View.GONE);
                    }
                });
        tvNameFood.setText(data.getTitle());
        tvPriceFood.setText(data.getPrice()+"円");
        return view;
    }
}
