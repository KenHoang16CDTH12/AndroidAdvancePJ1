package com.example.orderf_ood.view.main;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.orderf_ood.R;
import com.example.orderf_ood.view.home.HomeFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class HomeActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initView();
    }

    private void initView() {
        bottomNavigationView = findViewById(R.id.bottom_nav_bar);
        HomeFragment fragment = new HomeFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.content,fragment,"");
        fragmentTransaction.commit();

        bottomNavigationView.setOnItemSelectedListener(bottomSelectedListener);
    }
     private BottomNavigationView.OnItemSelectedListener  bottomSelectedListener = new NavigationBarView.OnItemSelectedListener(){
         @Override
         public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
             switch (menuItem.getItemId()){
                 case R.id.navigation_home:
                     HomeFragment fragment1 = new HomeFragment();
                     FragmentTransaction fragmentTransaction1 = getSupportFragmentManager().beginTransaction();
                     fragmentTransaction1.replace(R.id.content,fragment1,"");
                     fragmentTransaction1.commit();
                 case R.id.navigation_chat:
                     ChatFragment fragment2 = new ChatFragment();
                     FragmentTransaction fragmentTransaction2 = getSupportFragmentManager().beginTransaction();
                     fragmentTransaction2.replace(R.id.content,fragment2,"");
                     fragmentTransaction2.commit();
                 case R.id.navigation_history:
                     HistoryFragment fragment3= new HistoryFragment();
                     FragmentTransaction fragmentTransaction3 = getSupportFragmentManager().beginTransaction();
                     fragmentTransaction3.replace(R.id.content,fragment3,"");
                     fragmentTransaction3.commit();
                 case R.id.navigation_account:
                     AccountFragment fragment4 = new AccountFragment();
                     FragmentTransaction fragmentTransaction4 = getSupportFragmentManager().beginTransaction();
                     fragmentTransaction4.replace(R.id.content,fragment4,"");
                     fragmentTransaction4.commit();
             }
             return false;
         }
     };
}