package com.example.orderf_ood.model.tutorial;

public class TutorialInteract {
    // なし
}